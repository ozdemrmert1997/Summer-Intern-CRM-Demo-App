import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutternotsepeti/kategori_islemleri.dart';
import 'package:flutternotsepeti/models/kategori.dart';
import 'package:flutternotsepeti/models/notlar.dart';
import 'package:flutternotsepeti/not_detay.dart';
import 'package:flutternotsepeti/utils/database_helper.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        fontFamily: 'Raleway',
        primarySwatch: Colors.purple,
        accentColor: Colors.orange,
      ),
      home: NotListesi(),
    );
  }
}

class NotListesi extends StatefulWidget {
  static final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();

  @override
  _NotListesiState createState() => _NotListesiState();
}

class _NotListesiState extends State<NotListesi> {
  final DatabaseHelper _databaseHelper = DatabaseHelper();

  final GlobalKey<FormState> _formKey = GlobalKey();

  String _yeniKategori;

  @override
  Widget build(BuildContext context) {
    debugPrint("not build çalıştı");
    return Scaffold(
      key: NotListesi.scaffoldKey,
      appBar: AppBar(
        actions: <Widget>[
          PopupMenuButton(itemBuilder: (BuildContext context) {
            return [
              PopupMenuItem(
                child: ListTile(
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (BuildContext context) =>
                                KategoriListesi()));
                  },
                  leading: Icon(
                    Icons.import_contacts,
                    color: Colors.orange,
                  ),
                  title: Text("Kategoriler",
                      style: TextStyle(
                          color: Colors.blueGrey, fontWeight: FontWeight.w700)),
                ),
              ),
            ];
          }),
        ],
        title: Text(
          "Not Sepeti",
          style: TextStyle(fontFamily: "Raleway", fontWeight: FontWeight.w700),
        ),
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          FloatingActionButton(
            heroTag: "Kategori Ekle",
            onPressed: () {
              kategoriEkleDialog(context);
            },
            child: Icon(
              Icons.import_contacts,
              color: Colors.white,
            ),
            mini: true,
          ),
          FloatingActionButton(
            heroTag: "Not Ekle",
            onPressed: () {
              notEkleDialog(context);
            },
            child: Icon(
              Icons.add,
              color: Colors.white,
            ),
          ),
        ],
      ),
      body: Notlar(),
    );
  }

  void kategoriEkleDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return SimpleDialog(
          title: Text(
            "Kategori Ekle",
            style: TextStyle(
                fontFamily: "Raleway",
                fontWeight: FontWeight.w700,
                color: Colors.blueGrey),
          ),
          children: <Widget>[
            Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: "Kategori Adı",
                    border: OutlineInputBorder(),
                  ),
                  validator: (girilenDeger) {
                    if (girilenDeger.length < 3) {
                      return "En az 3 karakter giriniz";
                    } else
                      return null;
                  },
                  onSaved: (girilenDeger) => _yeniKategori = girilenDeger,
                ),
              ),
            ),
            ButtonBar(
              children: <Widget>[
                OutlineButton(
                  borderSide: BorderSide(color: Theme.of(context).primaryColor),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  color: Colors.orangeAccent,
                  child: Text(
                    "Vazgeç",
                    style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                OutlineButton(
                  borderSide: BorderSide(color: Theme.of(context).accentColor),
                  onPressed: () {
                    if (_formKey.currentState.validate()) {
                      _formKey.currentState.save();
                      _databaseHelper
                          .kategoriEkle(Kategori(_yeniKategori))
                          .then((kategoriID) {
                        if (kategoriID > 0) {
                          NotListesi.scaffoldKey.currentState.showSnackBar(
                            SnackBar(
                              content: Text("Kategori Eklendi"),
                              duration: Duration(seconds: 1),
                            ),
                          );
                          Navigator.of(context).pop();
                        }
                      });
                    }
                  },
                  color: Colors.redAccent,
                  child: Text(
                    "Kaydet",
                    style: TextStyle(
                        color: Theme.of(context).accentColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  void notEkleDialog(BuildContext context) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) =>
                NotDetay(baslik: "Yeni Not"))).then((value) => setState(() {}));
  }
}

class Notlar extends StatefulWidget {
  @override
  _NotlarState createState() => _NotlarState();
}

class _NotlarState extends State<Notlar> {
  DatabaseHelper _databaseHelper;
  List<Not> tumNotlar;

  @override
  void initState() {
    super.initState();
    _databaseHelper = DatabaseHelper();
    tumNotlar = List();
  }

  @override
  Widget build(BuildContext context) {
    TextStyle textStyleBaslik = Theme.of(context).textTheme.body1.copyWith(
        fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Raleway');
    return FutureBuilder(
        future: _databaseHelper.notListesiniGetir(),
        builder: (BuildContext context, AsyncSnapshot snopShot) {
          if (snopShot.connectionState == ConnectionState.done) {
            tumNotlar = snopShot.data;

            return ListView.builder(
                itemCount: tumNotlar.length,
                itemBuilder: (BuildContext context, int index) {
                  return ExpansionTile(
                    leading: _oncelikIconuAta(tumNotlar[index].notOncelik),
                    title: Text(
                      tumNotlar[index].notBaslik,
                      style: textStyleBaslik,
                    ),
                    subtitle: Text(
                      "Kategori: " + tumNotlar[index].kategoriBaslik,
                      style:
                      TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                    ),
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "Oluşturulma Tarihi",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    _databaseHelper.dateFormat(DateTime.parse(
                                        tumNotlar[index].notTarih)),
                                    style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20,
                                        color: Theme.of(context).accentColor),
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding:
                              const EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                "İçerik",
                                style: TextStyle(
                                    fontWeight: FontWeight.w700, fontSize: 14),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 14),
                              child: Text(
                                tumNotlar[index].notIcerik,
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 20,
                                    color: Colors.blueGrey),
                              ),
                            ),
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              mainAxisSize: MainAxisSize.max,
                              children: <Widget>[
                                OutlineButton(
                                  borderSide: BorderSide(
                                      color: Theme.of(context).primaryColor),
                                  onPressed: () =>
                                      _notSil(tumNotlar[index].notID),
                                  child: Text(
                                    "SİL",
                                    style: TextStyle(
                                        color: Theme.of(context).primaryColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                                OutlineButton(
                                  borderSide: BorderSide(
                                      color: Theme.of(context).accentColor),
                                  onPressed: () {
                                    notEkleDialog(context, tumNotlar[index]);
                                  },
                                  child: Text(
                                    "GÜNCELLE",
                                    style: TextStyle(
                                        color: Theme.of(context).accentColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                });
          } else {
            return CircularProgressIndicator();
          }
        });
  }

  void _notSil(int notID) {
    _databaseHelper.notSil(notID).then((onValue) {
      if (onValue > 0) {
        Scaffold.of(context).showSnackBar(
          SnackBar(
            content: Text("Not Silindi"),
            duration: Duration(seconds: 1),
          ),
        );
        setState(() {});
      }
    });
  }

  _oncelikIconuAta(int notOncelik) {
    switch (notOncelik) {
      case 0:
        return CircleAvatar(
            radius: 26,
            child: Text(
              "AZ",
              style: TextStyle(
                  color: Colors.deepOrange.shade200,
                  fontWeight: FontWeight.bold),
            ),
            backgroundColor: Colors.blueGrey.shade200);
        break;
      case 1:
        return CircleAvatar(
            radius: 26,
            child: Text(
              "ORTA",
              style: TextStyle(
                  color: Colors.deepOrange.shade400,
                  fontWeight: FontWeight.bold),
            ),
            backgroundColor: Colors.blueGrey.shade200);
      case 2:
        return CircleAvatar(
            radius: 26,
            child: Text(
              "ACIL",
              style: TextStyle(
                  color: Colors.deepOrange.shade700,
                  fontWeight: FontWeight.bold),
            ),
            backgroundColor: Colors.blueGrey.shade200);
        break;
    }
  }

  void notEkleDialog(BuildContext context, Not not) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) =>
                NotDetay(baslik: "Notu Güncelle", guncellenecekNot: not)));
  }
}